using UnityEngine;

/// <summary>
/// Lightweight debugger for StemController.
/// Attach anywhere; toggle 'showDebug' to get periodic logs.
/// </summary>
public sealed class StemDebugger : MonoBehaviour
{
    public StemController target;
    public bool showDebug = true;
    public float interval = 1f;
    float _next;

    void Update()
    {
        if (!showDebug) return;
        if (Time.unscaledTime < _next) return;
        _next = Time.unscaledTime + Mathf.Max(0.2f, interval);

        if (!target) target = FindFirstObjectByType<StemController>(FindObjectsInactive.Exclude);
        if (!target) { Debug.LogWarning("[StemDebugger] No StemController found."); return; }

        var v = target.vocalStem ? (target.vocalStem.isPlaying ? "playing" : "stopped") : "null";
        Debug.Log($"[StemDebugger] vocal={v}; mixer={(target.mixer? "yes":"no")}  hitStreak? { (target.tempo? target.tempo.CurrentCorrectStreak : -1)}  missStreak? { (target.tempo? target.tempo.CurrentMissStreak : -1)}");
    }
}

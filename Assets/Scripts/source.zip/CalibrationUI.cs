using System.Collections.Generic;
using UnityEngine;
using TMPro;
using System.IO;

public sealed class CalibrationUI : MonoBehaviour
{
    public Conductor conductor; public TapInput input; public TMP_Text statusText; public TMP_Text offsetText; public AudioSource click; public int beatsToTest=16;
    List<double> deltas=new List<double>(); bool running; double nextBeat;

    void OnEnable(){ if(input) input.OnTapDsp += OnTap; if(statusText) statusText.text="Ready. Press Start."; }
    void OnDisable(){ if(input) input.OnTapDsp -= OnTap; }

    public void StartCalibrate(){ if(running) return; deltas.Clear(); running=true; double B=conductor.SongBeats; nextBeat = System.Math.Ceiling(B+0.5); if(statusText) statusText.text="Calibrating..."; }

    void Update(){
        if(!running) return; double B=conductor.SongBeats;
        while(running && B>=nextBeat && deltas.Count<beatsToTest){ if(click && click.clip) click.Play(); nextBeat += 1.0; }
        if(deltas.Count>=beatsToTest) Finish();
    }
    void OnTap(double dsp){ if(!running) return; double bpm=conductor.bpm; double beatLen=60.0/bpm; double t=AudioSettings.dspTime-conductor.dspStartTime; double estBeat=System.Math.Round(t/beatLen); double exp=conductor.dspStartTime+estBeat*beatLen; double d=(dsp-exp)*1000.0; deltas.Add(d); if(offsetText) offsetText.text=$"samples:{deltas.Count} last Δ={d:0.0}ms"; }
    async void Finish(){ running=false; deltas.Sort(); double median=deltas[deltas.Count/2]; if(statusText) statusText.text=$"Estimated inputOffset ≈ {median:0.0}ms"; var cfg=await RemoteConfigLoader.LoadAsync(); cfg.inputOffsetMs=(int)System.Math.Round(median); string p=Path.Combine(Application.persistentDataPath,"RemoteConfig.json"); File.WriteAllText(p, JsonUtility.ToJson(cfg,true)); if(offsetText) offsetText.text=$"Saved: {p}"; }
}

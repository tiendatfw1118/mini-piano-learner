using UnityEngine;
public sealed class PoolableNote : MonoBehaviour, IPoolable { public void OnSpawned(){} public void OnDespawned(){} }

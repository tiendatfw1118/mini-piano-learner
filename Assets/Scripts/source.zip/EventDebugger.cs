using UnityEngine;
using SpeedItUp.Events;

/// <summary>
/// Simple debug script to test if GameEventBus events are working
/// </summary>
public class EventDebugger : MonoBehaviour
{
    void Start()
    {
        // Subscribe to all events to see if they're being published
        GameEventBus.SubscribeToNoteHit(OnNoteHit);
        GameEventBus.SubscribeToNoteMissed(OnNoteMissed);
        GameEventBus.SubscribeToHoldStarted(OnHoldStarted);
        GameEventBus.SubscribeToHoldCompleted(OnHoldCompleted);
        GameEventBus.SubscribeToHoldBroken(OnHoldBroken);
        
        Debug.Log("[EventDebugger] Subscribed to all GameEventBus events");
    }
    
    void OnDestroy()
    {
        // Unsubscribe from events
        GameEventBus.UnsubscribeFromNoteHit(OnNoteHit);
        GameEventBus.UnsubscribeFromNoteMissed(OnNoteMissed);
        GameEventBus.UnsubscribeFromHoldStarted(OnHoldStarted);
        GameEventBus.UnsubscribeFromHoldCompleted(OnHoldCompleted);
        GameEventBus.UnsubscribeFromHoldBroken(OnHoldBroken);
    }
    
    private void OnNoteHit(NoteData noteData, Judge judge)
    {
        Debug.Log($"[EventDebugger] NOTE HIT EVENT: {noteData.id}, Judge: {judge}");
    }
    
    private void OnNoteMissed(NoteData noteData)
    {
        Debug.Log($"[EventDebugger] NOTE MISSED EVENT: {noteData.id}");
    }
    
    private void OnHoldStarted(NoteData noteData)
    {
        Debug.Log($"[EventDebugger] HOLD STARTED EVENT: {noteData.id}");
    }
    
    private void OnHoldCompleted(NoteData noteData)
    {
        Debug.Log($"[EventDebugger] HOLD COMPLETED EVENT: {noteData.id}");
    }
    
    private void OnHoldBroken(NoteData noteData)
    {
        Debug.Log($"[EventDebugger] HOLD BROKEN EVENT: {noteData.id}");
    }
}

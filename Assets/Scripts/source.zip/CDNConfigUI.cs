using UnityEngine;
using UnityEngine.UI;
using TMPro;

/// <summary>
/// Simple UI component to configure CDN settings in the editor or at runtime
/// </summary>
public class CDNConfigUI : MonoBehaviour
{
    [Header("UI References")]
    public TMP_InputField cdnUrlInput;
    public TMP_InputField configEndpointInput;
    public TMP_InputField timeoutInput;
    public Toggle fallbackToggle;
    public Toggle cachingToggle;
    public Button saveButton;
    public Button testButton;
    public TMP_Text statusText;
    
    [Header("Default Settings")]
    public string defaultCDNUrl = "https://your-cdn-domain.com/game-config/";
    public string defaultConfigEndpoint = "RemoteConfig.json";
    public int defaultTimeoutSeconds = 10;
    public bool defaultEnableFallback = true;
    public bool defaultEnableCaching = true;
    
    void Start()
    {
        SetupUI();
        LoadCurrentSettings();
    }
    
    void SetupUI()
    {
        // Set default values if not assigned
        if (cdnUrlInput != null)
            cdnUrlInput.text = defaultCDNUrl;
        if (configEndpointInput != null)
            configEndpointInput.text = defaultConfigEndpoint;
        if (timeoutInput != null)
            timeoutInput.text = defaultTimeoutSeconds.ToString();
        if (fallbackToggle != null)
            fallbackToggle.isOn = defaultEnableFallback;
        if (cachingToggle != null)
            cachingToggle.isOn = defaultEnableCaching;
        
        // Setup button events
        if (saveButton != null)
            saveButton.onClick.AddListener(SaveSettings);
        if (testButton != null)
            testButton.onClick.AddListener(TestConnection);
        
        UpdateStatus("Ready to configure CDN");
    }
    
    void LoadCurrentSettings()
    {
        // Load settings from PlayerPrefs if they exist
        if (PlayerPrefs.HasKey("CDN_URL") && cdnUrlInput != null)
            cdnUrlInput.text = PlayerPrefs.GetString("CDN_URL");
        if (PlayerPrefs.HasKey("CDN_ENDPOINT") && configEndpointInput != null)
            configEndpointInput.text = PlayerPrefs.GetString("CDN_ENDPOINT");
        if (PlayerPrefs.HasKey("CDN_TIMEOUT") && timeoutInput != null)
            timeoutInput.text = PlayerPrefs.GetInt("CDN_TIMEOUT", defaultTimeoutSeconds).ToString();
        if (PlayerPrefs.HasKey("CDN_FALLBACK") && fallbackToggle != null)
            fallbackToggle.isOn = PlayerPrefs.GetInt("CDN_FALLBACK", 1) == 1;
        if (PlayerPrefs.HasKey("CDN_CACHING") && cachingToggle != null)
            cachingToggle.isOn = PlayerPrefs.GetInt("CDN_CACHING", 1) == 1;
    }
    
    public void SaveSettings()
    {
        try
        {
            string cdnUrl = cdnUrlInput != null ? cdnUrlInput.text : defaultCDNUrl;
            string configEndpoint = configEndpointInput != null ? configEndpointInput.text : defaultConfigEndpoint;
            int timeout = defaultTimeoutSeconds;
            
            if (timeoutInput != null && int.TryParse(timeoutInput.text, out int parsedTimeout))
            {
                timeout = parsedTimeout;
            }
            
            // Configure the CDN loader
            RemoteConfigLoader.ConfigureCDN(cdnUrl, configEndpoint, timeout);
            
            // Save to PlayerPrefs
            PlayerPrefs.SetString("CDN_URL", cdnUrl);
            PlayerPrefs.SetString("CDN_ENDPOINT", configEndpoint);
            PlayerPrefs.SetInt("CDN_TIMEOUT", timeout);
            PlayerPrefs.SetInt("CDN_FALLBACK", fallbackToggle != null && fallbackToggle.isOn ? 1 : 0);
            PlayerPrefs.SetInt("CDN_CACHING", cachingToggle != null && cachingToggle.isOn ? 1 : 0);
            PlayerPrefs.Save();
            
            UpdateStatus($"Settings saved! CDN: {cdnUrl}{configEndpoint}");
        }
        catch (System.Exception e)
        {
            UpdateStatus($"Error saving settings: {e.Message}");
        }
    }
    
    public async void TestConnection()
    {
        if (testButton != null)
            testButton.interactable = false;
        
        UpdateStatus("Testing CDN connection...");
        
        try
        {
            // Configure with current settings
            string cdnUrl = cdnUrlInput != null ? cdnUrlInput.text : defaultCDNUrl;
            string configEndpoint = configEndpointInput != null ? configEndpointInput.text : defaultConfigEndpoint;
            int timeout = defaultTimeoutSeconds;
            
            if (timeoutInput != null && int.TryParse(timeoutInput.text, out int parsedTimeout))
            {
                timeout = parsedTimeout;
            }
            
            RemoteConfigLoader.ConfigureCDN(cdnUrl, configEndpoint, timeout);
            
            // Test the connection
            var config = await RemoteConfigLoader.ForceReloadFromCDN();
            
            if (config != null)
            {
                UpdateStatus($"✅ Connection successful! BPM: {config.baseBpm}, Hit Window: {config.hitWindowMs.perfect}ms");
            }
            else
            {
                UpdateStatus("❌ Connection failed - check URL and network");
            }
        }
        catch (System.Exception e)
        {
            UpdateStatus($"❌ Test failed: {e.Message}");
        }
        finally
        {
            if (testButton != null)
                testButton.interactable = true;
        }
    }
    
    void UpdateStatus(string message)
    {
        if (statusText != null)
        {
            statusText.text = message;
        }
    }
    
    /// <summary>
    /// Quick setup method for programmatic configuration
    /// </summary>
    public static void QuickSetup(string cdnBaseUrl, string configEndpoint = "RemoteConfig.json")
    {
        RemoteConfigLoader.ConfigureCDN(cdnBaseUrl, configEndpoint);
    }
}

using UnityEngine;

// Optional: also play the tone immediately for keyboard 1..7 degree taps.
public class DegreeAuditioner : MonoBehaviour
{
    public TapInput input;
    public ScaleNoteAudio noteAudio;

    void OnEnable(){ if (!input) input = FindFirstObjectByType<TapInput>(); if (input) input.OnTapDegreeDsp += OnTap; }
    void OnDisable(){ if (input) input.OnTapDegreeDsp -= OnTap; }
    void OnTap(int degree, double _dsp){ 
        // DISABLED: This was causing duplicate audio playback
        // The JudgeController already handles audio playback
        // if (noteAudio) noteAudio.PlayDegree(degree); 
    }
}

﻿using UnityEngine;
using UnityEngine.InputSystem;

[DefaultExecutionOrder(-10)]
public class DifficultyTesterInputActions : MonoBehaviour
{
    [Header("Targets")]
    public TempoController tempoController;

    [Header("Input Actions (drag & drop OR use PlayerInput)")]
    public InputActionReference hitAction;
    public InputActionReference missAction;
    public InputActionReference resetAction;
    public InputActionReference incBpmAction;
    public InputActionReference decBpmAction;

    public PlayerInput playerInput;                      // optional
    public string hitActionName = "Hit";
    public string missActionName = "Miss";
    public string resetActionName = "Reset";
    public string incBpmActionName = "BpmUp";
    public string decBpmActionName = "BpmDown";

    [Header("Keyboard fallback")]
    public Key testCorrectKey = Key.Space;
    public Key testMissKey = Key.M;
    public Key resetKey = Key.R;
    public Key increaseBpmKey = Key.UpArrow;
    public Key decreaseBpmKey = Key.DownArrow;

    [Header("BPM Test Settings")]
    public int bpmStep = 10;
    public float minBpm = 60f;
    public float maxBpm = 200f;

    [Header("Debug")]
    public bool showDebugInfo = true;

    // resolved actions
    InputAction _aHit, _aMiss, _aReset, _aInc, _aDec;

    void Awake()
    {
        if (!tempoController)
            tempoController = FindFirstObjectByType<TempoController>(FindObjectsInactive.Exclude);

        _aHit = Resolve(hitAction, playerInput, hitActionName);
        _aMiss = Resolve(missAction, playerInput, missActionName);
        _aReset = Resolve(resetAction, playerInput, resetActionName);
        _aInc = Resolve(incBpmAction, playerInput, incBpmActionName);
        _aDec = Resolve(decBpmAction, playerInput, decBpmActionName);
    }

    void OnEnable()
    {
        // explicit subscribe so we can unsubscribe safely
        if (_aHit != null) { _aHit.performed += OnHitPerformed; _aHit.Enable(); }
        if (_aMiss != null) { _aMiss.performed += OnMissPerformed; _aMiss.Enable(); }
        if (_aReset != null) { _aReset.performed += OnResetPerformed; _aReset.Enable(); }
        if (_aInc != null) { _aInc.performed += OnIncBpmPerformed; _aInc.Enable(); }
        if (_aDec != null) { _aDec.performed += OnDecBpmPerformed; _aDec.Enable(); }
    }

    void OnDisable()
    {
        if (_aHit != null) _aHit.performed -= OnHitPerformed;
        if (_aMiss != null) _aMiss.performed -= OnMissPerformed;
        if (_aReset != null) _aReset.performed -= OnResetPerformed;
        if (_aInc != null) _aInc.performed -= OnIncBpmPerformed;
        if (_aDec != null) _aDec.performed -= OnDecBpmPerformed;
    }

    void Update()
    {
        if (!tempoController) return;

        // Nếu KHÔNG có action cho Hit, dùng phím fallback
        if (_aHit == null && Pressed(testCorrectKey)) TestCorrectHit();
        if (_aMiss == null && Pressed(testMissKey)) TestMiss();
        if (_aReset == null && Pressed(resetKey)) ResetTracking();

        // Per-action fallback cho BPM
        if (_aInc == null && Pressed(increaseBpmKey)) IncreaseBpm();
        if (_aDec == null && Pressed(decreaseBpmKey)) DecreaseBpm();
    }

    // ---------- Helpers ----------
    static InputAction Resolve(InputActionReference r, PlayerInput pi, string name)
    {
        if (r != null && r.action != null) return r.action;
        if (pi != null && !string.IsNullOrEmpty(name))
        {
            var a = pi.actions?.FindAction(name, throwIfNotFound: false);
            if (a != null) return a;
        }
        return null;
    }

    bool HasAnyActionBound()
    {
        return (_aHit != null) || (_aMiss != null) || (_aReset != null) || (_aInc != null) || (_aDec != null);
        // hoặc: return (_aHit?.enabled ?? false) || ... nếu bạn muốn chỉ tính khi action đã Enable
    }

    static bool Pressed(Key k)
    {
        if (k == Key.None || Keyboard.current == null) return false;
        try { return Keyboard.current[k].wasPressedThisFrame; }
        catch { return false; }
    }

    // ---------- Callbacks ----------
    void OnHitPerformed(InputAction.CallbackContext _) => TestCorrectHit();
    void OnMissPerformed(InputAction.CallbackContext _) => TestMiss();
    void OnResetPerformed(InputAction.CallbackContext _) => ResetTracking();
    void OnIncBpmPerformed(InputAction.CallbackContext _) => IncreaseBpm();
    void OnDecBpmPerformed(InputAction.CallbackContext _) => DecreaseBpm();

    // ---------- Test logic ----------
    void TestCorrectHit()
    {
        var randomJudge = (Judge)Random.Range(0, 3); // Perfect/Great/Good
        tempoController?.OnJudge(randomJudge);
    }

    void TestMiss() => tempoController?.OnJudge(Judge.Miss);
    void ResetTracking() => tempoController?.ResetTracking();

    void IncreaseBpm()
    {
        if (tempoController?.conductor == null) return;
        float cur = tempoController.conductor.bpm;
        float next = Mathf.Min(maxBpm, cur + bpmStep);
        if (Mathf.Abs(next - cur) > 0.01f)
        {
            tempoController.conductor.SetBpm(next);
        }
    }

    void DecreaseBpm()
    {
        if (tempoController?.conductor == null) return;
        float cur = tempoController.conductor.bpm;
        float next = Mathf.Max(minBpm, cur - bpmStep);
        if (Mathf.Abs(next - cur) > 0.01f)
        {
            tempoController.conductor.SetBpm(next);
        }
    }

    void OnGUI()
    {
        if (!showDebugInfo || tempoController == null) return;
        GUILayout.BeginArea(new Rect(10, 10, 340, 210), GUI.skin.window);
        GUILayout.Label("=== Difficulty System Tester (New Input System) ===");
        GUILayout.Label($"Current BPM: {tempoController.CurrentBpm:F1}");
        GUILayout.Label($"Combo: {tempoController.CurrentCombo}");
        GUILayout.Label($"Correct Streak: {tempoController.CurrentCorrectStreak}");
        GUILayout.Label($"Miss Streak: {tempoController.CurrentMissStreak}");
        GUILayout.Space(6);
        GUILayout.Label("Actions / Fallback:");
        GUILayout.Label($"Hit:    {(_aHit != null ? _aHit.name : testCorrectKey.ToString())}");
        GUILayout.Label($"Miss:   {(_aMiss != null ? _aMiss.name : testMissKey.ToString())}");
        GUILayout.Label($"Reset:  {(_aReset != null ? _aReset.name : resetKey.ToString())}");
        GUILayout.Label($"BPM + : {(_aInc != null ? _aInc.name : increaseBpmKey.ToString())}");
        GUILayout.Label($"BPM - : {(_aDec != null ? _aDec.name : decreaseBpmKey.ToString())}");
        GUILayout.Label($"Range: {minBpm}-{maxBpm} (step {bpmStep})");
        GUILayout.EndArea();
    }
}

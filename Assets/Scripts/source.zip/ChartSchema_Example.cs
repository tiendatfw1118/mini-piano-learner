#if false
// Example ONLY — Disabled by default to avoid duplicate definition.
// Add 'len' to your real ChartNote struct in your schema file instead.
[System.Serializable]
public struct ChartNote
{
    public string id;
    public double beat;
    public int lane;
    public int degree;
    public float len; // beats
}
#endif

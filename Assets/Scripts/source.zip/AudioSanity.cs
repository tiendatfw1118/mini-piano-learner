using UnityEngine;

public class AudioSanity : MonoBehaviour
{
    public ScaleNoteAudio noteAudio;
    void Start()
    {
        if (!noteAudio) noteAudio = FindFirstObjectByType<ScaleNoteAudio>();
        // DISABLED: This was playing random notes every 0.6 seconds
        // InvokeRepeating(nameof(Ping), 1f, 0.6f); // m?i 0.6s pht 1 n?t
    }
    void Ping()
    {
        // DISABLED: This was causing unwanted random audio playback
        // if (noteAudio) noteAudio.PlayDegree(Random.Range(1, 8));
        // else Debug.LogWarning("[AudioSanity] No ScaleNoteAudio found in scene.");
    }
}